from database import Customer, Employee, Product

def get_customers(session):
    # SELECT * from customers
    return session.query(Customer)


def get_customer_by_id(session, customer_id):
    # SELECT * FROM customers WHERE id = customer_id
    return session.query(Customer).get(customer_id)


def create_customer(session, customer_data):
    customer = Customer(
        first_name=customer_data["first_name"],
        last_name=customer_data["last_name"],
        city=customer_data["city"],
        email=customer_data["email"],
        phone=customer_data["phone"],
        vat=customer_data["vat"]
    )
    session.add(customer)
    session.commit()

    return customer


def get_employees(session):
    return session.query(Employee)


def get_employee_by_id(session, employee_id):
    return session.query(Employee).get(employee_id)


def get_products(session):
    return session.query(Product)


def get_product_by_id(session, product_id):
    return session.query(Product).get(product_id)
