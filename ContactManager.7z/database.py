import sqlalchemy as db
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class Customer(Base):
    __tablename__ = "customers"  # ovako će nam se zvati tablica u bazi

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String, nullable=False)
    last_name = db.Column(db.String, nullable=False)
    city = db.Column(db.String)
    email = db.Column(db.String, nullable=False, unique=True)
    phone = db.Column(db.String)
    vat = db.Column(db.String, nullable=False, unique=True)  # OIB

    # product_id = db.Column(db.Integer, db.ForeignKey("products.id"))

    def __str__(self):
        # ovo se pozove kad nad objektom ove klase
        # pozovemo (str) ili kad napravimo print tog objekta
        return f"{self.id}. {self.first_name} {self.last_name}"
    
    def print_customer_in_gui(self):
        return f"{self.id}. {self.first_name} {self.last_name}, {self.email} {self.city}"


class Employee(Base):
    __tablename__ = "employees"

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String, nullable=False)
    last_name = db.Column(db.String, nullable=False)
    city = db.Column(db.String)
    email = db.Column(db.String, nullable=False, unique=True)
    phone = db.Column(db.String)
    vat = db.Column(db.String, nullable=False, unique=True)  # OIB
    position = db.Column(db.String, nullable=False)

    def __str__(self):
        return f"{self.id}. {self.first_name} {self.last_name}"


class Product(Base):
    __tablename__ = "products"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False, unique=True)
    description = db.Column(db.String)
    price = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)

    def __str__(self):
        return f"{self.id}. {self.name}"
