import tkinter as tk

import crud
from main import session

root = tk.Tk()
root.title("Algebra | Contact Manager")


def create_customer():
    new_customer_window = tk.Toplevel(root)
    new_customer_window.title("Kreiranje kupca")
    new_customer_window.focus()
    
    first_name_var = tk.StringVar()
    first_name_label = tk.Label(new_customer_window, text="Ime")
    first_name_label.grid(row=0, column=0, padx=20, pady=20)
    first_name_entry = tk.Entry(new_customer_window, textvariable=first_name_var)
    first_name_entry.grid(row=0, column=1, padx=20, pady=20)

    last_name_var = tk.StringVar()
    last_name_label = tk.Label(new_customer_window, text="Prezime")
    last_name_label.grid(row=1, column=0, padx=20, pady=20)
    last_name_entry = tk.Entry(new_customer_window, textvariable=last_name_var)
    last_name_entry.grid(row=1, column=1, padx=20, pady=20)

    city_var = tk.StringVar()
    city_label = tk.Label(new_customer_window, text="Grad")
    city_label.grid(row=2, column=0, padx=20, pady=20)
    city_entry = tk.Entry(new_customer_window, textvariable=city_var)
    city_entry.grid(row=2, column=1, padx=20, pady=20)

    email_var = tk.StringVar()
    email_label = tk.Label(new_customer_window, text="Email")
    email_label.grid(row=3, column=0, padx=20, pady=20)
    email_entry = tk.Entry(new_customer_window, textvariable=email_var)
    email_entry.grid(row=3, column=1, padx=20, pady=20)

    phone_var = tk.StringVar()
    phone_label = tk.Label(new_customer_window, text="Telefon")
    phone_label.grid(row=4, column=0, padx=20, pady=20)
    phone_entry = tk.Entry(new_customer_window, textvariable=phone_var)
    phone_entry.grid(row=4, column=1, padx=20, pady=20)

    vat_var = tk.StringVar()
    vat_label = tk.Label(new_customer_window, text="OIB")
    vat_label.grid(row=5, column=0, padx=20, pady=20)
    vat_entry = tk.Entry(new_customer_window, textvariable=vat_var)
    vat_entry.grid(row=5, column=1, padx=20, pady=20)

    def save_customer():
        customer = crud.create_customer(
            session,
            {
                "first_name": first_name_var.get(),
                "last_name": last_name_var.get(),
                "city": city_var.get(),
                "email": email_var.get(),
                "phone": phone_var.get(),
                "vat": vat_var.get()
            }
        )
        new_customer_window.destroy()  # zatvara nam otvoreni prozor
        show_customers()  # refresh liste


    save_customer_button = tk.Button(new_customer_window, text="Spremi", command=save_customer)
    save_customer_button.grid(row=6, column=0, columnspan=2, padx=20, pady=20)


def show_customers():
    customer_listbox = tk.Listbox(data_frame, width=100)
    index = 1
    customers = crud.get_customers(session)
    for customer in customers:
        customer_listbox.insert(index, customer.print_customer_in_gui())
        index += 1
    
    customer_listbox.grid(row=0, column=0, padx=10, pady=10)
    create_new_customer_button = tk.Button(data_frame, text="Kreiraj novog kupca", command=create_customer)
    create_new_customer_button.grid(row=0, column=1, padx=10, pady=10)


def create_company_frame():
    company_frame = tk.LabelFrame(root, width=600, height=150, text="Podaci o tvrtci")
    company_frame.grid(row=0, column=0, padx=10, pady=10)

    company_name_label = tk.Label(company_frame, text="Naziv tvrtke")
    company_name_label_value = tk.Label(
        company_frame, width=50, font=("Times", 20), text="Microsoft"
    )
    company_name_label.grid(row=0, column=0, padx=10, pady=10)
    company_name_label_value.grid(row=0, column=1, padx=10, pady=10)

    company_address_label = tk.Label(company_frame, text="Adresa tvrtke")
    company_address_label_value = tk.Label(
        company_frame, width=50, font=("Times", 20), text="Times Square"
    )
    company_address_label.grid(row=1, column=0, padx=10, pady=10)
    company_address_label_value.grid(row=1, column=1, padx=10, pady=10)

    company_vat_label = tk.Label(company_frame, text="OIB tvrtke")
    company_vat_label_value = tk.Label(
        company_frame, width=50, font=("Times", 20), text="12345678910"
    )
    company_vat_label.grid(row=2, column=0, padx=10, pady=10)
    company_vat_label_value.grid(row=2, column=1, padx=10, pady=10)


def create_buttons_frame():
    button_frame = tk.LabelFrame(
        root, width=600, height=100, text="Akcije"
    )
    button_frame.grid(row=1, column=0, padx=10, pady=10)

    show_customers_button = tk.Button(
        button_frame, text="Prikaži kupce", command=show_customers
    )
    show_customers_button.grid(row=0, column=0, padx=10, pady=10)

    show_employees_button = tk.Button(
        button_frame, text="Prikaži zaposlenike"
    )
    show_employees_button.grid(row=0, column=1, padx=10, pady=10)

    show_products_button = tk.Button(
        button_frame, text="Prikaži proizvode"
    )
    show_products_button.grid(row=0, column=2, padx=10, pady=10)


create_company_frame()
create_buttons_frame()


data_frame = tk.LabelFrame(root, width=600, height=200, text="Podaci")
data_frame.grid(row=2, column=0, padx=10, pady=10)




root.mainloop()
