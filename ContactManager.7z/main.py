from requests import Session
import sqlalchemy as db
from sqlalchemy.orm import sessionmaker

from database import Base, Customer, Employee
import crud

db_name = "ContactManager.db"
db_engine = db.create_engine(f"sqlite:///{db_name}")

# kreiramo bazu podatako i tablice unutar nje
# checkfirst će provjeriti da li tablice u bazi već
# postoje i ako da, neće odraditi CREATE TABLE naredbe
Base.metadata.create_all(db_engine, checkfirst=True)

Session = sessionmaker()
Session.configure(bind=db_engine)
session = Session()  # ovo nam je "otvorena veza" prema bazi podataka
# putem nje radimo sve upite prema bazi

# customers = crud.get_customers(session)

# employee_1 = crud.get_employee_by_id(session, 1)

# employee_3 = crud.get_employee_by_id(session, 3)

""" nikola_tesla = crud.create_customer(
    session,
    {
        "first_name": "Nikola",
        "last_name": "Tesla",
        "city": "Smiljan",
        "email": "nikola@tesla.hr",
        "phone": "01234567",
        "vat": "1234567"
    }
)
print(nikola_tesla) """
