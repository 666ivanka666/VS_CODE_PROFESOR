from email.policy import default
import datetime as dt
import sqlalchemy as db
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class TemperatureReading(Base):
    __tablename__ = "temperature_readings"

    id = db.Column(db.Integer, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=dt.datetime.now)


class HumidityReading(Base):
    __tablename__ = "humidity_readings"

    id = db.Column(db.Integer, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=dt.datetime.now)


class PressureReading(Base):
    __tablename__ = "pressure_readings"

    id = db.Column(db.Integer, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=dt.datetime.now)