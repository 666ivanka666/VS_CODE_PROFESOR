from pprint import pprint
import requests
import xmltodict


class XMLMeteoParser:
    def __init__(self, city):
        self.city = city
        self.url = "https://vrijeme.hr/hrvatska_n.xml"
    
    def request_data(self):
        response = requests.get(self.url)
        return xmltodict.parse(response.content)

    def find_city_data(self):
        meteo_data = self.request_data()
        for city in meteo_data["Hrvatska"]["Grad"]:
            if city["GradIme"] == self.city:
                return city["Podatci"]
