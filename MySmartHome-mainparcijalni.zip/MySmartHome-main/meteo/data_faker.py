import datetime as dt
import random as rd

class DataFaker:
    """
    This class is used for faking temperature, humidity and pressure data
    since we are not using the SenseHat Emulator to get those readings.
    """
    def generate_temperature_reading(self, temperature):
        """
        Generate temperature reading that +- 5 degrees compared to the
        given temperature.
        """
        return round(rd.uniform(float(temperature) - 5, float(temperature) + 5), 1)
    
    def generate_humidity_reading(self, humidity):
        """
        Generate humidity reading that +- 5 % compared to the
        given humidity.
        """
        min_value = humidity - 5 if humidity -5 >= 0 else 0
        max_value = humidity + 5 if humidity + 5 <= 100 else 0

        return round(rd.uniform(float(min_value), float(max_value)), 1)

    def generate_pressure_reading(self, pressure):
        """
        Generate pressure reading that +- 8 hPa compared to the
        given pressure.
        """

        return round(rd.uniform(float(pressure) - 8, float(pressure) + 8), 1)
