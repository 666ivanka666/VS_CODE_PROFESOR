import tkinter as tk

from meteo.api import XMLMeteoParser
from meteo.data_faker import DataFaker

from meteo.crud import create_temperature_reading, create_humidity_reading, create_pressure_reading


class MeteoModule(tk.Frame):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.font = ("Arial", 15)
        self.clothes_var = tk.StringVar()
        self.create_outdoor_vars() # kreiramo varijable u koje cemo staviti vrijednosti
        self.get_outdoor_data() # dohvatimo vanjske vrijednosti iz XML-a
        self.create_indoor_vars() # kreiramo varijable za unutarnje vrijednosti
        self.get_indoor_data() # na temelju vanjskih cemo generirati unutarnje vrijednosti
        self.create_indoor_frame()
        self.create_outdoor_frame()
        self.create_clothes_label()

    def create_outdoor_vars(self):
        self.outdoor_temperature_var = tk.StringVar()
        self.outdoor_humidity_var = tk.StringVar()
        self.outdoor_pressure_var = tk.StringVar()

    def get_outdoor_data(self):
        meteo_parser = XMLMeteoParser("Zagreb-Grič")
        city_data = meteo_parser.find_city_data()

        outdoor_data = {
            "temperature": float(city_data["Temp"]),
            "humidity": float(city_data["Vlaga"]),
            "pressure": float(city_data["Tlak"])
        }
        self.outdoor_temperature_var.set(str(outdoor_data["temperature"]))
        self.outdoor_humidity_var.set(str(outdoor_data["humidity"]))
        self.outdoor_pressure_var.set(str(outdoor_data["pressure"]))
    
    def create_indoor_vars(self):
        self.indoor_temperature_var = tk.StringVar()
        self.indoor_humidity_var = tk.StringVar()
        self.indoor_pressure_var = tk.StringVar()
        
    def get_indoor_data(self):
        # generiramo "fake" unutarnje vrijednosti na temelju vanjskih
        data_faker = DataFaker()
        session = self.master.Session()

        # generiramo fake vrijednost unutarnje temperature na temelju vanjske
        indoor_temperature_value = data_faker.generate_temperature_reading(
            float(self.outdoor_temperature_var.get())
        )
        # zapisujeo tu vrijednost u bazu
        create_temperature_reading(session=session, value=indoor_temperature_value)
        # spremamo tu vrijednost u varijablu koja nam je vezana na label
        self.indoor_temperature_var.set(str(indoor_temperature_value))

        indoor_humidity_value = data_faker.generate_humidity_reading(
            round(float(self.outdoor_humidity_var.get()), 1)
        )
        create_humidity_reading(session=session, value=indoor_humidity_value)
        self.indoor_humidity_var.set(str(indoor_humidity_value))

        indoor_pressure_value = data_faker.generate_pressure_reading(
            round(float(self.outdoor_pressure_var.get()), 1)
        )
        create_pressure_reading(session=session, value=indoor_pressure_value)
        self.indoor_pressure_var.set(str(indoor_pressure_value))
    
    def create_indoor_temperature_label(self):
        self.indoor_temp_label = tk.Label(
            self.indoor_frame, text="Temperature (°C)", font=self.font
        )
        self.indoor_temp_label.grid(row=0, column=0, padx=10, pady=10)

        self.indoor_temp_value = tk.Label(
            self.indoor_frame, textvariable=self.indoor_temperature_var, font=self.font
        )
        self.indoor_temp_value.grid(row=0, column=1, padx=10, pady=10)
    
    def create_indoor_humidity_label(self):
        self.indoor_humidity_label = tk.Label(
            self.indoor_frame, text="Humidity (%)", font=self.font
        )
        self.indoor_humidity_label.grid(row=1, column=0, padx=10, pady=10)

        self.indoor_humidity_value = tk.Label(
            self.indoor_frame, textvariable=self.indoor_humidity_var, font=self.font
        )
        self.indoor_humidity_value.grid(row=1, column=1, padx=10, pady=10)
    
    def create_indoor_pressure_label(self):
        self.indoor_pressure_label = tk.Label(
            self.indoor_frame, text="Pressure (hPa)", font=self.font
        )
        self.indoor_pressure_label.grid(row=2, column=0, padx=10, pady=10)

        self.indoor_pressure_value = tk.Label(
            self.indoor_frame, textvariable=self.indoor_pressure_var, font=self.font
        )
        self.indoor_pressure_value.grid(row=2, column=1, padx=10, pady=10)

    def create_indoor_labels(self):
        self.create_indoor_temperature_label()
        self.create_indoor_humidity_label()
        self.create_indoor_pressure_label()
    
    def create_outdoor_labels(self):
        self.create_outdoor_temperature_label()
        self.create_outdoor_humidity_label()
        self.create_outdoor_pressure_label()
    
    def create_outdoor_temperature_label(self):
        self.outdoor_temp_label = tk.Label(
            self.outdoor_frame, text="Temperature (°C)", font=self.font
        )
        self.outdoor_temp_label.grid(row=0, column=0, padx=10, pady=10)

        self.outdoor_temp_value = tk.Label(
            self.outdoor_frame, textvariable=self.outdoor_temperature_var, font=self.font
        )
        self.outdoor_temp_value.grid(row=0, column=1, padx=10, pady=10)
        self.set_clothes_var()

    def create_outdoor_humidity_label(self):
        self.outdoor_humidity_label = tk.Label(
            self.outdoor_frame, text="Humidity (%)", font=self.font
        )
        self.outdoor_humidity_label.grid(row=1, column=0, padx=10, pady=10)

        self.outdoor_humidity_value = tk.Label(
            self.outdoor_frame, textvariable=self.outdoor_humidity_var, font=self.font
        )
        self.outdoor_humidity_value.grid(row=1, column=1, padx=10, pady=10)
    
    def create_outdoor_pressure_label(self):
        self.outdoor_pressure_label = tk.Label(
            self.outdoor_frame, text="Pressure (hPa)", font=self.font
        )
        self.outdoor_pressure_label.grid(row=2, column=0, padx=10, pady=10)

        self.outdoor_pressure_value = tk.Label(
            self.outdoor_frame, textvariable=self.outdoor_pressure_var, font=self.font
        )
        self.outdoor_pressure_value.grid(row=2, column=1, padx=10, pady=10)

    def create_indoor_frame(self):
        self.indoor_frame = tk.LabelFrame(
            self, text="Indoor values", width=400, height=400,
            font=self.font
        )
        self.indoor_frame.grid(row=0, column=0)

        def refresh_values():
            self.get_indoor_data()
            self.after(10000, refresh_values)
        
        self.create_indoor_labels()
        refresh_values()

    def create_outdoor_frame(self):
        self.outdoor_frame = tk.LabelFrame(
            self, text="Outdoor values", width=400, height=400,
            font=self.font
        )
        self.outdoor_frame.grid(row=0, column=1)

        self.create_outdoor_labels()
    
    def set_clothes_var(self):
        outdoor_temp = float(self.outdoor_temperature_var.get())
        if outdoor_temp > 22:
            clothes = "short sleeves"
        elif 12 <= outdoor_temp <= 22:
            clothes = "light jacket"
        elif 0 <= outdoor_temp < 12:
            clothes = "warm jacket"
        else:
            clothes = "warm jacket, scarf and a cap"
        self.clothes_var.set(
            f"Based on the temperature, {clothes} is recommended."
        )

    def create_clothes_label(self):
        self.clothes_label = tk.Label(
            self, textvariable=self.clothes_var, font=self.font
        )
        self.clothes_label.grid(row=1, column=0, columnspan=2, padx=10, pady=10)
    