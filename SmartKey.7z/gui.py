import tkinter as tk

import sqlalchemy as sql
from sqlalchemy.orm import sessionmaker

from db import Base
from crud import get_by_pin, get_only_active_users, get_by_id, get_all_users


class PinMessageFrame(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.parent = parent
        self.keypad_numbers = [
            ["1", "2", "3"],
            ["4", "5", "6"],
            ["7", "8", "9"],
            ["C", "0", "DEL", "BCK"]
        ]

        # self.create_keypad_frame()
        # self.create_message_frame()

    def create_keypad_frame(self):
        self.current_pin = ""
        self.keypad_frame = tk.Frame(self, width=360, height=300, bg="#D3D3D3")
        self.keypad_frame.grid(row=0, column=0, padx=20, pady=20)

        self.generate_pin_number_fields()
        self.generate_keypad()

    def create_message_frame(self, text):
        self.message_frame = tk.Message(self, width=350, text=text, bg="#D4D4D3")
        self.message_frame.grid(row=0, column=1, padx=20, pady=20)

    def generate_pin_number_fields(self):
        self.pin_digit_1 = tk.Button(self.keypad_frame, text="", width=2, height=2)
        self.pin_digit_2 = tk.Button(self.keypad_frame, text="", width=2, height=2)
        self.pin_digit_3 = tk.Button(self.keypad_frame, text="", width=2, height=2)
        self.pin_digit_4 = tk.Button(self.keypad_frame, text="", width=2, height=2)

        self.pin_digit_1.grid(row=0, column=0, padx=15, pady=15)
        self.pin_digit_2.grid(row=0, column=1, padx=15, pady=15)
        self.pin_digit_3.grid(row=0, column=2, padx=15, pady=15)
        self.pin_digit_4.grid(row=0, column=3, padx=15, pady=15)


    def generate_keypad(self):
        for row_index, row in enumerate(self.keypad_numbers):
            for column_index, number in enumerate(row):
                number_button = tk.Button(self.keypad_frame, text=number, width=2, height=2, command=lambda x=number: self.keypad_press(x))
                number_button.grid(row=row_index + 1, column=column_index, padx=10, pady=10)

    def append_pin_digit(self, number):
        self.current_pin += number
        current_digit_index = len(self.current_pin) # koliko trenutno imamo znamenki u pinu

        pin_digit_button = getattr(self, f"pin_digit_{current_digit_index}", None)  # dinamicki dohvatimo onaj pin_digit gumb koji nam treba
        # inace moramo provjeravati
        # if current_digit_index == 1:
        #    self.pin_digit_1.configure(text=number)
        # elif current_digit_index == 2:
        #    self.pin_digit_2.configure(text=number)
        # elif current_digit_index == 3:
        #    self.pin_digit_3.configure(text=number)
        # else:
        #    self.pin_digit_4.configure(text=number)
        if pin_digit_button:
            pin_digit_button.configure(text=number)

    def delete_last_pin_digit(self):
        current_digit_index = len(self.current_pin)
        pin_digit_button = getattr(self, f"pin_digit_{current_digit_index}")
        pin_digit_button.configure(text="")
        self.current_pin = self.current_pin[:-1]

    def delete_pin(self):
        self.current_pin = ""
        self.pin_digit_1.configure(text="")
        self.pin_digit_2.configure(text="")
        self.pin_digit_3.configure(text="")
        self.pin_digit_4.configure(text="")

    def delete_keypad_frame(self):
        self.current_pin = ""  # pin na prazan string
        self.keypad_frame.destroy()  # uništavamo cijeli frame u kojem nam je i tipkovnica
        self.message_frame.destroy()  # uništavamo i message frame za slučaj da smo imali poruku u njemu
        self.parent.button_frame.unlock_button.configure(state="normal")  # enableamo button za otključavamo

    def check_pin(self):
        session = self.parent.Session()  # session za upit prema bazi
        user = get_by_pin(session, self.current_pin)  # provjeramo da li postoji aktivni korisnik sa trenutnim pinom

        if user:
            self.create_message_frame(f"Welcome home, {user}")
            if user.admin:
                self.parent.create_admin_frame()
            else:
                self.message_frame.after(7500, self.reset_pin)
        else:
            self.create_message_frame("Wrong pin, please try again...")
            self.message_frame.after(5000, self.reset_pin)

    def reset_pin(self):
        self.message_frame.destroy()
        self.current_pin = ""
        self.delete_pin()

    def keypad_press(self, number):
        if number.isdigit():
            # stisnuli smo broj i dodajemo tu znamenku u trenutni pin
            self.append_pin_digit(number)
        elif number == "C":
            # stisnuli smo C i brišemo zadnju znamenku
            self.delete_last_pin_digit()
        elif number == "DEL":
            # stisnuli smo DEL i brišemo cijeli trenutno upisani pin
            self.delete_pin()
        else:
            # stisnuli smo BCK i mičemo cijeli keypad i enableamo button
            self.delete_keypad_frame()


        if len(self.current_pin) == 4:
            self.check_pin()


class AdminFrame(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.parent = parent

        self.create_user_list_frame()
        self.create_user_edit_frame()

    def create_user_list_frame(self):
        self.user_list_frame = tk.Frame(self, width=260, height=200)
        self.user_list_frame.grid(row=0, column=0, padx=20, pady=20)

        self.list_users()

    def list_users(self):
        session = self.parent.Session()
        users = get_all_users(session)

        for index, user in enumerate(users):
            user_button = tk.Button(
                self.user_list_frame, text=f"Name: {user} (ID: {user.id})", relief=tk.FLAT,
                command=lambda x=user: self.populate_user_data(x)
            )
            user_button.grid(row=index, column=0, padx=10, pady=10)

    def populate_user_data(self, user):
        self.id_var.set(user.id)
        self.first_name_var.set(user.first_name)
        self.last_name_var.set(user.last_name)
        self.pin_name_var.set(user.pin)

        self.active_var.set(user.active)
        self.admin_var.set(user.admin)


    def create_user_edit_frame(self):
        self.user_edit_frame = tk.Frame(self, width=450, height=200)
        self.user_edit_frame.grid(row=0, column=1, padx=20, pady=20)

        self.id_var = tk.StringVar()
        self.id_label = tk.Label(self.user_edit_frame, text="ID:", font=("Arial", 10))
        self.id_entry = tk.Entry(self.user_edit_frame, textvariable=self.id_var, relief=tk.FLAT, state="disabled")
        self.id_label.grid(row=0, column=0, padx=10, pady=10)
        self.id_entry.grid(row=0, column=1, padx=10, pady=10)

        self.first_name_var = tk.StringVar()
        self.first_name_label = tk.Label(self.user_edit_frame, text="First Name:", font=("Arial", 10))
        self.first_name_entry = tk.Entry(self.user_edit_frame, textvariable=self.first_name_var, relief=tk.FLAT)
        self.first_name_label.grid(row=1, column=0, padx=10, pady=10)
        self.first_name_entry.grid(row=1, column=1, padx=10, pady=10)

        self.last_name_var = tk.StringVar()
        self.last_name_label = tk.Label(self.user_edit_frame, text="Last Name:", font=("Arial", 10))
        self.last_name_entry = tk.Entry(self.user_edit_frame,  textvariable=self.last_name_var, relief=tk.FLAT)
        self.last_name_label.grid(row=2, column=0, padx=10, pady=10)
        self.last_name_entry.grid(row=2, column=1, padx=10, pady=10)

        self.pin_name_var = tk.StringVar()
        self.pin_label = tk.Label(self.user_edit_frame, text="Current pin", font=("Arial", 10))
        self.pin_entry = tk.Entry(self.user_edit_frame, textvariable=self.pin_name_var, relief=tk.FLAT)
        self.pin_label.grid(row=3, column=0, padx=10, pady=10)
        self.pin_entry.grid(row=3, column=1, padx=10, pady=10)

        self.active_var = tk.IntVar()
        self.active_checkbox = tk.Checkbutton(self.user_edit_frame, text="Is active?", variable=self.active_var, onvalue=1, offvalue=0)
        self.active_checkbox.grid(row=4, column=0, padx=10, pady=10)

        self.admin_var = tk.IntVar()
        self.admin_checkbox = tk.Checkbutton(self.user_edit_frame, text="Is admin?", variable=self.admin_var, onvalue=1, offvalue=0)
        self.admin_checkbox.grid(row=5, column=0, padx=10, pady=10)

        self.save_button = tk.Button(self.user_edit_frame, text="Save", command=self.save)
        self.save_button.grid(row=6, column=0, padx=10, pady=10)

        self.cancel_button = tk.Button(self.user_edit_frame, text="Cancel", command=self.cancel)
        self.cancel_button.grid(row=6, column=1, padx=10, pady=10)

        self.delete_button = tk.Button(self.user_edit_frame, text="Delete", command=self.delete)
        self.delete_button.grid(row=6, column=2, padx=10, pady=10)

    def save(self):
        # TODO spremanje korisnika
        pass

    def delete(self):
        # TODO brisanje korisnika
        pass

    def cancel(self):
        self.id_var.set("")
        self.first_name_var.set("")
        self.last_name_var.set("")
        self.pin_name_var.set("")

        self.active_var.set(0)
        self.admin_var.set(0)



class ButtonFrame(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.parent = parent

        self.create_ring_button()
        self.create_unlock_button()


    def create_ring_button(self):
        self.ring_button = tk.Button(self, text="Ring", command=self.ring)
        self.ring_button.grid(row=0, column=0, padx=20, pady=20)

    def create_unlock_button(self):
        self.unlock_button = tk.Button(self, text="Unlock", command=self.unlock)
        self.unlock_button.grid(row=0, column=1, padx=20, pady=20)

    def ring(self):
        self.parent.create_pin_message_frame()
        self.parent.pin_message_frame.create_message_frame(text="Someone will be with you shorty, please wait...")
        self.ring_button.configure(state="disabled")

        def destroy_message_frame():
            self.parent.pin_message_frame.message_frame.destroy()
            self.ring_button.configure(state="normal")


        self.after(10000, destroy_message_frame)  # nakon 10 sekundi mičemo poruku i enableamo button za pozvoniti


    def unlock(self):
        self.parent.create_pin_message_frame()
        self.unlock_button.configure(state="disabled")
        self.parent.pin_message_frame.create_keypad_frame()



class SmartKeyApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Algebra | Smart:Key")

        self.initialize_db()

        self.create_button_frame()
        # self.create_pin_message_frame()
        # self.create_admin_frame()

    def initialize_db(self):
        db_engine = sql.create_engine("sqlite:///SmartKey.db")
        Base.metadata.create_all(db_engine, checkfirst=True) # kreiramo bazu ako već ne postoji
        self.Session = sessionmaker(bind=db_engine)  # Session objekt preko kojeg ćemo kreirati session instancu kad nam bude trebala

    def create_button_frame(self):
        self.button_frame = ButtonFrame(self, width=710, height=100)
        self.button_frame.grid(row=0, column=0, padx=20, pady=20)

    def create_pin_message_frame(self):
        self.pin_message_frame = PinMessageFrame(self, width=710, height=300, bg="#D3D3D3")
        self.pin_message_frame.grid(row=1, column=0, padx=20, pady=20)

    def create_admin_frame(self):
        self.admin_frame = AdminFrame(self, width=710, height=200, bg="#D3D3D3")
        self.admin_frame.grid(row=2, column=0, padx=20, pady=20)



app = SmartKeyApp()


app.mainloop()
