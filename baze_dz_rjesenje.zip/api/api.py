import json
import requests

person_url = "https://jsonplaceholder.typicode.com/users"


def get_people_list():
    response = requests.get(person_url)
    people_list = json.loads(response.text)

    return people_list


def prepare_person_for_saving(person_dict):
    # s obzirom da je osoba koju dohvatimo sa API-ja u drukčijem formatu od
    # onog kako je nama u bazi, trebamo najprije pripremiti dictionary
    # u odgovarajući format

    return {
        "first_name": person_dict.get("name").split()[0],
        "last_name": person_dict.get("name").split()[1],
        "email": person_dict.get("email"),
        "username": person_dict.get("username"),
        "phone": person_dict.get("phone"),
        "address": {
            "street": person_dict.get("address")["street"],
            "city": person_dict.get("address")["city"],
            "zipcode": person_dict.get("address")["zipcode"]
        }
    }
