from .models import Address


def get_all_addresses(session):
    """
    Funkcija koja služi za dohvat svih adresa koje imamo u bazi.

    :param session: predstavlja session objekt preko kojeg radimo upite prema bazi
    :return:
    """
    # session.query(Address) radi upit na bazu i odgovara ovom SQL-u
    # SELECT * from addresses;
    return session.query(Address)


def count_addresses(session):
    return session.query(Address).count()


def get_address(session, address_id):
    """
    Funkcija za dohvat jedne adrese prema ID-u.

    :param session: predstavlja session objekt preko kojeg radimo upite prema bazi
    :param person_id: ID osobe koju želimo dohvatiti
    :return:
    """

    # dohvaćamo adresu koja ima id = address_id
    # odgovara sljedećem SQL-U:
    # SELECT * from addresses where id = 1;

    # .get služi za dohvat po PK-u (primarnom ključu)
    # ako hoćemo filtrirati po nečem drugom
    # možete koristiti .filter
    # return session.query(Address).filter_by(zipcode='10000')  -> vraća listu objekata
    # return session.query(Address).filter(Address.city == 'Zagreb')  -> vraća listu objekata

    return session.query(Address).get(address_id)  # -> vraća jedan objekt (ako postoji)


def check_if_address_exists(session, street, city, zipcode):
    """
    Funkcija koja provjerava da li adresa već postoji.

    :param session: predstavlja session objekt preko kojeg radimo upite prema bazi
    :param street: ulica
    :param city: grad
    :param zipcode: poštanski broj
    :return:
    """

    # radimo upit na bazu i provjeravamo da li adresa sa ovim podacima već postoji
    # one_or_none() će nam vratiti ili objekt tipa Address ako postoji u bazi ili None
    address = session.query(Address).filter(
        Address.city == city, Address.street == street, Address.zipcode == zipcode
    ).one_or_none()

    return address


def create_new_address(session, address_dict):
    """
    Funkcija za kreiranje nove adrese u bazi.

    :param session: predstavlja session objekt preko kojeg radimo upite prema bazi
    :param address_dict: dictionary u kojem su nam podaci o adresi dohvaćeni sa "https://jsonplaceholder.typicode.com/users"
    :return:
    """

    # dohvatimo sve potrebne vrijednosti iz dictionarya
    street = address_dict.get("street")
    city = address_dict.get("city")
    zipcode = address_dict.get("zipcode")

    # provjerimo da li adresa već postoji
    address = check_if_address_exists(session, street, city, zipcode)

    if not address:
        # ako adresa ne postoji otprije, instanciramo novi Address objekt
        address = Address(street=street, city=city, zipcode=zipcode)

        # u session objekt dodajemo taj objekt (pripremamo ga za dodavanje u bazu)
        session.add(address)

        # pohranjujemo novu adresu u bazu
        session.commit()

    # vracamo kreiranu adresu za slučaj da nam treba izvan funkcije
    return address


def delete_address(session, address_id):
    session.query(Address).filter(Address.id == address_id).delete()
    session.commit()


def update_address(session, address_id, address_dict):
    # prvo dohvatimo adresu po ID-u
    address_query = session.query(Address).filter(Address.id == address_id)

    # nakon tog updateamo sa vrijednostima iz dictionary za kojeg se naravno moramo
    # pobrinuti da ima ispravne vrijednosti
    address_query.update(address_dict)

    session.commit()
