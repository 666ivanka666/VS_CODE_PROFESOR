import sqlalchemy as db
from sqlalchemy.orm import relationship, backref

from ..base import Base


class Address(Base):
    __tablename__ = "addresses"

    id = db.Column(db.Integer, primary_key=True)
    street = db.Column(db.String, nullable=False)
    city = db.Column(db.String, nullable=False)
    zipcode = db.Column(db.String)

    people = relationship("Person", backref=backref("addresses"))
