import random
import random as rd

from .models import Book


def get_all_books(session):
    return session.query(Book)


def count_books(session):
    return session.query(Book).count()


def get_random_book(session):
    return random.choice(session.query(Book).all())


def get_book(session, book_id):
    return session.query(Book).get(book_id)


def check_if_book_exists(session, title):
    book = session.query(Book).filter(
        Book.title == title
    ).one_or_none()

    return book


def create_new_book(session, book_dict):
    title = book_dict.get("title")
    price = book_dict.get("price")
    currency = book_dict.get("currency")
    rating = book_dict.get("rating")

    book = check_if_book_exists(session, title)

    if not book:
        book = Book(title=title, price=price, currency=currency, rating=rating)
        session.add(book)
        session.commit()

    return book


def delete_book(session, book_id):
    session.query(Book).filter(Book.id == book_id).delete()
    session.commit()


def update_book(session, book_id, book_dict):
    # prvo dohvatimo adresu po ID-u
    book_query = session.query(Book).filter(Book.id == book_id)

    # nakon tog updateamo sa vrijednostima iz dictionary za kojeg se naravno moramo
    # pobrinuti da ima ispravne vrijednosti
    book_query.update(book_dict)

    session.commit()

