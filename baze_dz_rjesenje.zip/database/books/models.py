import sqlalchemy as db
from sqlalchemy.orm import relationship, backref

from ..base import Base


class Book(Base):
    __tablename__ = "books"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String, nullable=False, unique=True)  # svaka knjiga mora imati naslov i mora biti jedinstven
    price = db.Column(db.Float)  # iznos
    currency = db.Column(db.String)  # valuta
    rating = db.Column(db.Integer)

    people = relationship("Person", backref=backref("books"))
