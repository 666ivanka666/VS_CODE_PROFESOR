from .models import Person


def get_all_people(session):
    return session.query(Person)


def get_person(session, person_id):
    return session.query(Person).get(person_id)


def count_people(session):
    return session.query(Person).count()


def check_if_person_exists(session, username=None, email=None):
    # provjeravamo po username ili email jer su nam oni unique
    person = None
    if username:
        person = session.query(Person).filter(
            Person.username == username
        ).one_or_none()
    elif email:
        person = session.query(Person).filter(
            Person.email == email
        ).one_or_none()

    return person


def create_new_person(session, person_dict):
    first_name = person_dict.get("first_name")
    last_name = person_dict.get("last_name")
    email = person_dict.get("email")
    username = person_dict.get("username")
    phone = person_dict.get("phone")
    favorite_book_id = person_dict.get("favorite_book_id")
    address_id = person_dict.get("address_id")

    person = check_if_person_exists(session, username, email)

    if not person:
        person = Person(
            first_name=first_name,
            last_name=last_name,
            email=email,
            username=username,
            phone=phone,
            favorite_book_id=favorite_book_id,
            address_id=address_id
        )
        session.add(person)
        session.commit()

    return person


def delete_person(session, person_id):
    session.query(Person).filter(Person.id == person_id).delete()
    session.commit()


def update_person(session, person_id, person_dict):
    # prvo dohvatimo adresu po ID-u
    person_query = session.query(Person).filter(Person.id == person_id)

    # nakon tog updateamo sa vrijednostima iz dictionary za kojeg se naravno moramo
    # pobrinuti da ima ispravne vrijednosti
    person_query.update(person_dict)

    session.commit()
