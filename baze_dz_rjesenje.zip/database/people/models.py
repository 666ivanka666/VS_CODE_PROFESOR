import sqlalchemy as db

from ..base import Base


class Person(Base):
    __tablename__ = 'people'

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String, nullable=False)
    last_name = db.Column(db.String, nullable=False)
    email = db.Column(db.String, unique=True, nullable=False)
    username = db.Column(db.String, unique=True, nullable=False)
    phone = db.Column(db.String)
    favorite_book_id = db.Column(db.Integer, db.ForeignKey("books.id"))
    address_id = db.Column(db.Integer, db.ForeignKey("addresses.id"))
