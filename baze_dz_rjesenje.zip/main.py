import sqlalchemy as db
from sqlalchemy.orm import sessionmaker

from database import base
from database.address.models import Address
from database.books.models import Book
from database.people.models import Person
from api.api import get_people_list, prepare_person_for_saving
from scraper.scraper import get_books, prepare_book_for_saving
from database.address import crud as address_crud
from database.books import crud as books_crud
from database.people import crud as person_crud

# naziv baze
db_name = "Books.db"

# kreiramo engine za povezivanje s bazom
db_engine = db.create_engine(f"sqlite:///{db_name}")

# kreiramo sve tablice koje smo definirali
base.Base.metadata.create_all(db_engine, checkfirst=True)

# kreiramo Session unutar kojeg ćemo raditi upite prema bazi
Session = sessionmaker()
Session.configure(bind=db_engine)
session = Session()

# dohvatiti knjige i osobe (time i adrese) te ih spremiti u bazu
books_dictionary = get_books()
for book_scraped in books_dictionary:
    # book_scraped je jedan dictionary koji smo dobili scrapeanjem
    book_dict = prepare_book_for_saving(book_scraped)  # pripremo odgovarajući format za spremanje u bazu
    book = books_crud.create_new_book(session, book_dict)  # kreiramo novu knjigu u bazi


people_json = get_people_list()
for person_json in people_json:
    # svaki person je jedan dictionary koji smo dohvatili sa JSON API-ja
    person_dict = prepare_person_for_saving(person_json)
    address_dict = person_dict.pop("address")
    address = address_crud.create_new_address(session, address_dict)
    book = books_crud.get_random_book(session)  # dohvatimo nasumicnu jednu knjigu iz baze
    person_dict["address_id"] = address.id
    person_dict["favorite_book_id"] = book.id
    person = person_crud.create_new_person(session, person_dict)

# isprobamo par CRUD operacija koje smo definirali

print("\n******* ADRESE *******\n")

# adresa s ID = 1
address_id_1 = address_crud.get_address(session, 1)
print(address_id_1.id, address_id_1.city, address_id_1.street)

# adresa ID koji ne postoji
address_non_existent = address_crud.get_address(session, 100)
print(address_non_existent)  # None

# sve adrese
addresses = address_crud.get_all_addresses(session)
for address_db in addresses:
    print(address_db.id, address_db.city, address_db.street)

# ukupan broj adresa koje imamo u bazi
address_count = address_crud.count_addresses(session)
print(f"Ukupan broj adresa u bazi: {address_count}")


# dodavanje nove adrese u bazu
new_address = address_crud.create_new_address(session, {"street": "Ilica", "zipcode": 10000, "city": "Zagreb"})
print(new_address.id, new_address.city, new_address.street)
address_count = address_crud.count_addresses(session)
print(f"Ukupan broj adresa u bazi: {address_count}")  # sada bi trebali imati jednu više jer smo jednu kreirali

# izmjene adrese
address_crud.update_address(session, new_address.id, {"street": "Gradišćanska"})  # možemo pogledat u bazi da li nam je ulica ažurirana
# ili jednostavno ponovno dohvatiti taj zapis iz baze
zagreb_address = address_crud.get_address(session, new_address.id)
print(zagreb_address.id, zagreb_address.city, zagreb_address.street)

# brisanje adrese
address_crud.delete_address(session, zagreb_address.id)
zagreb_address = address_crud.get_address(session, new_address.id)  # None

address_count = address_crud.count_addresses(session)
print(f"Ukupan broj adresa u bazi: {address_count}")  # sada bi trebali imati jednak broj kao i na početku jer smo jednu obrisali



# CRUD operacija nad ostalim tablicama slobodno isprobajte sami
