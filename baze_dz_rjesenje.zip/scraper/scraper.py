import requests

from bs4 import BeautifulSoup

books_url = "https://books.toscrape.com"


grade_mapping = {
    "One": 1,
    "Two": 2,
    "Three": 3,
    "Four": 4,
    "Five": 5
}


def parse_grade(tag):
    css_class = tag["class"]
    for grade_str, grade_int in grade_mapping.items():
        if grade_str in css_class:
            return grade_int


def get_books():
    response = requests.get(books_url)  # šaljemo request prema stranici sa podacima o knjigama
    content = BeautifulSoup(response.content, "html.parser")  # kreiramo novi BeautifulSoup objekt

    prices = content.select(".price_color")
    ratings = content.select(".star-rating")
    titles = content.select(".product_pod h3 a")

    books = []

    for title_tag, rating_tag, price_tag in zip(titles, ratings, prices):
        books.append(
            {
                "title": title_tag["title"],
                "price": price_tag.text,
                "rating": parse_grade(rating_tag)
            }
        )

    return books


def prepare_book_for_saving(book_dict):
    # s obzirom da su stupci u bazi malo drukciji od onog
    # sto scrapeamo (konkretno, cijenu screpamo kao £51.77, a u bazi su nam
    # to dva razlicita polja - price i currency), trebamo ih pripremiti za spremanje u bazu
    return {
        "title": book_dict.get("title"),
        "price": float(book_dict.get("price")[1:]),  # dohvatimo sve od prvog indeksa nadalje ('51.77') i to pretvorimo u float
        "currency": book_dict.get("price")[0],  # dohvatimo prvi znak, tj £
        "rating": book_dict.get("rating")
    }
