class Osoba:
    def __init__(self, ID, ime, OIB, grad, telefon, email):
        self.ID = ID
        self.ime = ime
        self.OIB = OIB
        self.grad = grad
        self.telefon = telefon
        self.email = email


class Tvrtka(Osoba):
    def __init__(self, ID, ime, OIB, grad, telefon, email):
        super().__init__(ID, ime, OIB, grad, telefon, email)
        self.lista_djelatnika = []
        self.lista_kupaca = []


class Kupac(Osoba):
    def __init__(self, ID, ime, prezime, OIB, grad, telefon, email):
        super().__init__(ID, ime, OIB, grad, telefon, email)
        self.prezime = prezime


class Djelatnik(Osoba):
    def __init__(self, ID, ime, prezime, OIB, grad, pozicija, telefon, email):
        super().__init__(ID, ime, OIB, grad, telefon, email)
        self.prezime = prezime
        self.pozicija = pozicija


tvrtka = Tvrtka(1, "PyDev", "12345678910", "Zagreb", "01234567", "py@dev.com")

try:
    with open("djelatnici.txt", "r") as file_reader:
        for red in file_reader:
            red = red.rstrip()
            dijelovi = red.split(";")
            djelatnik = Djelatnik(
                dijelovi[0],    # id
                dijelovi[1],    # ime
                dijelovi[2],    # prezime
                dijelovi[3],    # OIB
                dijelovi[4],    # grad
                dijelovi[5],    # pozicija
                dijelovi[6],    # telefon
                dijelovi[7]     # email
            )
            tvrtka.lista_djelatnika.append(djelatnik)
except Exception as e:
    print(f"Dogodila se greška {e}")


try:
    with open("kupci.txt", "r") as file_reader:
        for red in file_reader:
            red = red.rstrip()
            dijelovi = red.split(";")
            kupac = Kupac(
                dijelovi[0],    # id
                dijelovi[1],    # ime
                dijelovi[2],    # prezime
                dijelovi[3],    # OIB
                dijelovi[4],    # grad
                dijelovi[5],    # telefon
                dijelovi[6]     # email
            )
            tvrtka.lista_kupaca.append(kupac)
except Exception as e:
    print(f"Dogodila se greška {e}")


# čisto za provjera
for djelatnik in tvrtka.lista_djelatnika:
    print(djelatnik.ime, djelatnik.prezime)

for kupac in tvrtka.lista_kupaca:
    print(kupac.ime, kupac.prezime)


try:
    with open("tvrtka.txt", "w") as file_writer:
        file_writer.write(
            f"{tvrtka.ime}\n{tvrtka.OIB}\n{tvrtka.grad}\n{len(tvrtka.lista_djelatnika)}\n{len(tvrtka.lista_kupaca)}"
        )
except Exception as e:
    print(f"Dogodila se greška {e}")