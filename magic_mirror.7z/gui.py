import tkinter as tk
import sqlalchemy as db
from sqlalchemy.orm import sessionmaker
from datetime_utils import *
from database import Base

db_name = "MagicMirror.db"
db_engine = db.create_engine(f"sqlite:///{db_name}")
Base.metadata.create_all(db_engine, checkfirst=True)

Session = sessionmaker()
Session.configure(bind=db_engine)

session = Session()


root = tk.Tk()
root.title("Algebra | MagicMirror2")
root.configure(bg="#282828") # tamno siva pozadina

def create_datetime_frame():
    def refresh_time():
        now_time = formatted_time()
        time_label.configure(text=now_time)
        time_label.after(1000, refresh_time)

    datetime_frame = tk.Frame(
        root, width=100, height=50, bg="#282828"
    )
    datetime_frame.grid(row=0, column=0, padx=15, pady=15)

    today = formatted_date()
    now_time = formatted_time()

    date_label = tk.Label(
        datetime_frame, bg="#282828", fg="white",
        text=today, font=("Arial", 15)
    )
    date_label.grid(row=0, column=0, padx=10, pady=5)
    time_label = tk.Label(
        datetime_frame, bg="#282828", fg="white",
        text=now_time, font=("Arial", 20)
    )
    time_label.grid(row=1, column=0, padx=10, pady=5)
    refresh_time()

def create_weather_frame():
    weather_frame = tk.Frame(
        root, width=200, height=100,
        bg="white"
    )
    weather_frame.grid(row=0, column=2, padx=15, pady=15)

def create_quote_frame():
    quotes_frame = tk.Frame(
        root, width=300, height=100,
        bg="white"
    )
    quotes_frame.grid(row=1, column=0, columnspan=3, padx=15, pady=15)

def create_crypto_frame():
    crypto_frame = tk.Frame(
        root, width=150, height=150, bg="white"
    )
    crypto_frame.grid(row=2, column=0, columnspan=2, padx=15, pady=15)

create_datetime_frame()
create_weather_frame()
create_quote_frame()
create_crypto_frame()

root.mainloop()
