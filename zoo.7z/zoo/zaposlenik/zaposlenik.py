class Zaposlenik:
    def __init__(self, ime, prezime, pozicija, omiljena_zivotinja=None):
        self.ime = ime
        self.prezime = prezime
        self.pozicija = pozicija
        self.omiljena_zivotinja = omiljena_zivotinja
    
    def naziv(self):
        return f"{self.ime} {self.prezime}, {self.pozicija}"
    
    def ispisi_omiljenu_zivotinju(self):
        if self.omiljena_zivotinja:
            naziv_zivotinje = self.omiljena_zivotinja.naziv()
            print(naziv_zivotinje)
        else:
            print(f"{self.ime} nema omiljenu životinju.")
    
    def nahrani_omiljenu_zivotinju(self):
        if self.omiljena_zivotinja:
            self.omiljena_zivotinja.nahrani()
        else:
            print(f"{self.ime} nema omiljenu životinju koju može nahraniti.")
