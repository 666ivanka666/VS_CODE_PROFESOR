class Zivotinja:
    def __init__(self, tip, ime, glad):
        self.tip = tip
        self.ime = ime
        self.glad = glad
    
    def naziv(self):
        return f"{self.tip} {self.ime}"
    
    def nahrani(self):
        if self.glad:
            print(f"{self.naziv()} je nahranjen!")
            self.glad = False
        else:
            print(f"{self.naziv()} nije gladan, pokušaj kasnije..")
