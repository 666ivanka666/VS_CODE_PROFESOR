from zivotinja.zivotinja import Zivotinja
from zaposlenik.zaposlenik import Zaposlenik

import datetime as dt


class Zoo:
    def __init__(self, naziv, grad, radno_vrijeme_od, radno_vrijeme_do, cijena_ulaznica):
        self.naziv = naziv
        self.grad = grad
        self.radno_vrijeme_od = radno_vrijeme_od
        self.radno_vrijeme_do = radno_vrijeme_do
        self.cijena_ulaznica = cijena_ulaznica
        self.lista_zaposlenika = []
        self.lista_zivotinja = []
    
    def kreiraj_zivotinju(self):
        tip = input("Upišite tip životinje: \t")
        ime = input("Upišite ime životinje: \t")
        glad = input("Je li životinja gladna? (y/n) \t")
        if glad.lower() == 'y':
            glad = True
        else:
            glad = False
        
        zivotinja = Zivotinja(tip, ime, glad)
        self.lista_zivotinja.append(zivotinja)

        return zivotinja
    
    def ispisi_zaposlenike(self):
        for zaposlenik in self.lista_zaposlenika:
            print(zaposlenik.naziv())
    
    def ispisi_zivotinje(self):
        for zivotinja in self.lista_zivotinja:
            print(zivotinja.naziv())
    
    def kreiraj_zaposlenika(self):
        ime = input("Unesite ime zaposlenika: \t")
        prezime = input("Unesite prezime zaposlenika: \t")
        pozicija = input("Unesite poziciju zaposlenika: \t")
        ima_omiljenu_zivotinju = input("Ima li zaposlenik omiljenu životinju? (y/n)")
        if ima_omiljenu_zivotinju.lower() == 'y':
            omiljena_zivotinja = self.kreiraj_zivotinju()
        else:
            omiljena_zivotinja = None
        
        zaposlenik = Zaposlenik(ime, prezime, pozicija, omiljena_zivotinja)

        self.lista_zaposlenika.append(zaposlenik)
        return zaposlenik
    
    def zoo_otvoren(self):
        sada = dt.datetime.now().time()
        if self.radno_vrijeme_od <= sada and self.radno_vrijeme_do >= sada:
            return True
        else:
            return False


zoo_naziv = input("Unesite naziv zoološkog vrta: \t")
zoo_grad = input("Unesite grad u kojem se ZOO nalazi: \t")
radno_vrijeme_od_unos = input("Unesite vrijeme kad se ZOO otvara (HH:MM): \t")
# 08:30
radno_vrijeme_od = dt.datetime.strptime(radno_vrijeme_od_unos, "%H:%M").time()

radno_vrijeme_do_unos = input("Unesite vrijeme kad se ZOO zatvara (HH:MM): \t")
radno_vrijeme_do = dt.datetime.strptime(radno_vrijeme_do_unos, "%H:%M").time()

cijena_ulaznica = float(input("Unesite cijenu ulaznica za ZOO: \t"))

zoo = Zoo(zoo_naziv, zip, radno_vrijeme_od, radno_vrijeme_do, cijena_ulaznica)

while True:
    unos_zivotinje = input("Želite li kreirati novu životinju? (y/n) \t")
    if unos_zivotinje.lower() == "y":
        zoo.kreiraj_zivotinju()
    else:
        break

while True:
    unos_zaposlenika = input("Želite li kreirati novog zaposlenika? (y/n) \t")
    if unos_zaposlenika.lower() == "y":
        zoo.kreiraj_zaposlenika()
    else:
        break

zoo.ispisi_zaposlenike()
zoo.ispisi_zivotinje()
print(zoo.zoo_otvoren())
